create function pg_catalog.to_timestamp(double precision) returns timestamp with time zone
LANGUAGE SQL
AS $$
select ('epoch'::pg_catalog.timestamptz + $1 * '1 second'::pg_catalog.interval)
$$;
